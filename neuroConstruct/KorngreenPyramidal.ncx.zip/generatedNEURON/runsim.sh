cd '/home/matteo/korngreen-pyramidal/neuroConstruct/generatedNEURON'
/usr/local/nrn/x86_64/bin/nrngui KorngreenPyramidal.hoc